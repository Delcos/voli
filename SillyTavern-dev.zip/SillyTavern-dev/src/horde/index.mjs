import AIHorde from './index.js'
export default AIHorde
export { AIHorde }